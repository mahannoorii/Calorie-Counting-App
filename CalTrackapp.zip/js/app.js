/* CalTrack — a tiny, private, offline calorie counter.
   All data lives in localStorage on this device. */
(() => {
  'use strict';

  const STORE_KEY = 'caltrack.days.v1';
  const GOAL_KEY = 'caltrack.goal.v1';
  const DEFAULT_GOAL = 2000;
  const RING_CIRC = 2 * Math.PI * 52; // matches r=52 in the SVG

  const MEALS = [
    { id: 'breakfast', label: 'Breakfast' },
    { id: 'lunch', label: 'Lunch' },
    { id: 'dinner', label: 'Dinner' },
    { id: 'snack', label: 'Snacks' },
  ];

  // A few common foods for the quick autocomplete list (name -> kcal).
  const COMMON_FOODS = {
    'Banana': 105, 'Apple': 95, 'Egg': 78, 'Toast': 75, 'Coffee (black)': 2,
    'Latte': 120, 'Oatmeal': 150, 'Greek yogurt': 100, 'Chicken breast': 165,
    'Rice (1 cup)': 205, 'Avocado': 240, 'Almonds (handful)': 160,
    'Salad': 150, 'Sandwich': 350, 'Pizza slice': 285, 'Pasta (1 cup)': 220,
    'Protein shake': 180, 'Orange': 62, 'Granola bar': 150, 'Dark chocolate': 155,
  };

  // ---- State ----
  let state = loadDays();
  let goal = loadGoal();
  let currentDate = todayKey();
  let editingId = null;

  // ---- Elements ----
  const $ = (id) => document.getElementById(id);
  const els = {
    dayLabel: $('dayLabel'), prevDay: $('prevDay'), nextDay: $('nextDay'),
    consumed: $('consumedVal'), goal: $('goalVal'), remaining: $('remainingVal'),
    ring: $('ringProgress'),
    mealBreakfast: $('mealBreakfast'), mealLunch: $('mealLunch'),
    mealDinner: $('mealDinner'), mealSnack: $('mealSnack'),
    list: $('entryList'),
    addBtn: $('addBtn'), settingsBtn: $('settingsBtn'),
    sheet: $('sheet'), foodForm: $('foodForm'), sheetTitle: $('sheetTitle'),
    foodName: $('foodName'), foodCals: $('foodCals'), foodMeal: $('foodMeal'),
    commonFoods: $('commonFoods'),
    settingsSheet: $('settingsSheet'), settingsForm: $('settingsForm'),
    goalInput: $('goalInput'), clearDayBtn: $('clearDayBtn'),
  };

  // ---- Persistence ----
  function loadDays() {
    try { return JSON.parse(localStorage.getItem(STORE_KEY)) || {}; }
    catch { return {}; }
  }
  function saveDays() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch {}
  }
  function loadGoal() {
    const g = parseInt(localStorage.getItem(GOAL_KEY), 10);
    return Number.isFinite(g) && g > 0 ? g : DEFAULT_GOAL;
  }
  function saveGoal() {
    try { localStorage.setItem(GOAL_KEY, String(goal)); } catch {}
  }

  // ---- Date helpers ----
  function todayKey() { return dateKey(new Date()); }
  function dateKey(d) {
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  }
  function shiftDate(key, delta) {
    const [y, m, d] = key.split('-').map(Number);
    const dt = new Date(y, m - 1, d);
    dt.setDate(dt.getDate() + delta);
    return dateKey(dt);
  }
  function prettyDate(key) {
    if (key === todayKey()) return 'Today';
    if (key === shiftDate(todayKey(), -1)) return 'Yesterday';
    const [y, m, d] = key.split('-').map(Number);
    const dt = new Date(y, m - 1, d);
    return dt.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
  }

  // ---- Data access ----
  function entriesFor(key) { return state[key] || []; }
  function addEntry(entry) {
    if (!state[currentDate]) state[currentDate] = [];
    state[currentDate].push(entry);
    saveDays();
  }
  function updateEntry(id, patch) {
    const list = state[currentDate] || [];
    const e = list.find((x) => x.id === id);
    if (e) Object.assign(e, patch);
    saveDays();
  }
  function removeEntry(id) {
    state[currentDate] = entriesFor(currentDate).filter((e) => e.id !== id);
    if (state[currentDate].length === 0) delete state[currentDate];
    saveDays();
  }

  // ---- Rendering ----
  function render() {
    els.dayLabel.textContent = prettyDate(currentDate);
    const entries = entriesFor(currentDate);

    const totals = { breakfast: 0, lunch: 0, dinner: 0, snack: 0 };
    entries.forEach((e) => { totals[e.meal] = (totals[e.meal] || 0) + e.cals; });
    const consumed = entries.reduce((s, e) => s + e.cals, 0);

    // Summary numbers
    els.consumed.textContent = consumed.toLocaleString();
    els.goal.textContent = goal.toLocaleString();
    const remaining = goal - consumed;
    els.remaining.textContent = remaining >= 0
      ? `${remaining.toLocaleString()} left`
      : `${Math.abs(remaining).toLocaleString()} over`;
    els.remaining.style.color = remaining >= 0 ? 'var(--green)' : 'var(--danger)';

    els.mealBreakfast.textContent = totals.breakfast;
    els.mealLunch.textContent = totals.lunch;
    els.mealDinner.textContent = totals.dinner;
    els.mealSnack.textContent = totals.snack;

    // Ring
    const pct = goal > 0 ? Math.min(consumed / goal, 1) : 0;
    els.ring.style.strokeDashoffset = String(RING_CIRC * (1 - pct));
    els.ring.style.stroke = consumed > goal ? 'var(--danger)' : 'var(--green)';

    // Entry list grouped by meal
    els.list.innerHTML = '';
    if (entries.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'empty';
      empty.innerHTML = '<div class="big">🍽️</div><p>No food logged yet.<br>Tap + to add your first item.</p>';
      els.list.appendChild(empty);
      return;
    }

    MEALS.forEach((meal) => {
      const mealEntries = entries.filter((e) => e.meal === meal.id);
      if (mealEntries.length === 0) return;

      const group = document.createElement('section');
      group.className = 'meal-group';

      const head = document.createElement('div');
      head.className = 'meal-head';
      const total = mealEntries.reduce((s, e) => s + e.cals, 0);
      head.innerHTML = `<span class="meal-title">${meal.label}</span><span class="meal-total">${total} kcal</span>`;
      group.appendChild(head);

      mealEntries.forEach((e) => group.appendChild(entryRow(e)));
      els.list.appendChild(group);
    });
  }

  function entryRow(e) {
    const row = document.createElement('div');
    row.className = 'entry';

    const info = document.createElement('div');
    info.className = 'entry-info';
    info.tabIndex = 0;
    info.innerHTML = `<div class="entry-name"></div><div class="entry-cals">${e.cals} kcal</div>`;
    info.querySelector('.entry-name').textContent = e.name; // safe from HTML injection
    info.addEventListener('click', () => openFoodSheet(e));

    const del = document.createElement('button');
    del.className = 'entry-del';
    del.setAttribute('aria-label', `Delete ${e.name}`);
    del.textContent = '🗑️';
    del.addEventListener('click', (ev) => {
      ev.stopPropagation();
      removeEntry(e.id);
      render();
    });

    row.append(info, del);
    return row;
  }

  // ---- Sheets ----
  function openFoodSheet(entry) {
    editingId = entry ? entry.id : null;
    els.sheetTitle.textContent = entry ? 'Edit food' : 'Add food';
    els.foodName.value = entry ? entry.name : '';
    els.foodCals.value = entry ? entry.cals : '';
    els.foodMeal.value = entry ? entry.meal : guessMeal();
    showSheet(els.sheet);
    setTimeout(() => els.foodName.focus(), 50);
  }
  function guessMeal() {
    const h = new Date().getHours();
    if (h < 11) return 'breakfast';
    if (h < 15) return 'lunch';
    if (h < 21) return 'dinner';
    return 'snack';
  }
  function openSettings() {
    els.goalInput.value = goal;
    showSheet(els.settingsSheet);
  }
  function showSheet(sheet) { sheet.classList.remove('hidden'); }
  function hideSheet(sheet) { sheet.classList.add('hidden'); }

  // ---- Events ----
  els.addBtn.addEventListener('click', () => openFoodSheet(null));
  els.settingsBtn.addEventListener('click', openSettings);
  els.prevDay.addEventListener('click', () => { currentDate = shiftDate(currentDate, -1); render(); });
  els.nextDay.addEventListener('click', () => { currentDate = shiftDate(currentDate, 1); render(); });
  els.dayLabel.addEventListener('click', () => { currentDate = todayKey(); render(); });

  // Close any sheet via backdrop / cancel buttons
  document.querySelectorAll('[data-close]').forEach((el) => {
    el.addEventListener('click', () => {
      hideSheet(els.sheet);
      hideSheet(els.settingsSheet);
    });
  });

  // Autofill calories when a known food is chosen and the field is empty
  els.foodName.addEventListener('change', () => {
    const known = COMMON_FOODS[els.foodName.value];
    if (known != null && !els.foodCals.value) els.foodCals.value = known;
  });

  els.foodForm.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const name = els.foodName.value.trim();
    const cals = Math.round(Number(els.foodCals.value));
    if (!name || !Number.isFinite(cals) || cals < 0) return;
    const meal = els.foodMeal.value;

    if (editingId) {
      updateEntry(editingId, { name, cals, meal });
    } else {
      addEntry({ id: cryptoId(), name, cals, meal });
    }
    hideSheet(els.sheet);
    render();
  });

  els.settingsForm.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const g = Math.round(Number(els.goalInput.value));
    if (Number.isFinite(g) && g > 0) { goal = g; saveGoal(); }
    hideSheet(els.settingsSheet);
    render();
  });

  els.clearDayBtn.addEventListener('click', () => {
    if (confirm(`Clear all entries for ${prettyDate(currentDate)}?`)) {
      delete state[currentDate];
      saveDays();
      hideSheet(els.settingsSheet);
      render();
    }
  });

  function cryptoId() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return 'id-' + Date.now() + '-' + Math.random().toString(16).slice(2);
  }

  // ---- Init ----
  function buildFoodDatalist() {
    els.commonFoods.innerHTML = '';
    Object.keys(COMMON_FOODS).forEach((name) => {
      const opt = document.createElement('option');
      opt.value = name;
      els.commonFoods.appendChild(opt);
    });
  }

  buildFoodDatalist();
  render();

  // ---- Service worker (offline + installable) ----
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('service-worker.js').catch(() => {});
    });
  }
})();
