#!/usr/bin/env python3
"""Generate CalTrack PWA icons (no third-party deps).

Draws a rounded green gradient tile with a white flame, plus a maskable
variant and an Apple touch icon. Re-run after changing the look:
    python3 tools/make_icons.py
"""
import os
import zlib
import struct
import math

OUT_DIR = os.path.join(os.path.dirname(__file__), '..', 'icons')

GREEN_TOP = (22, 163, 74)
TEAL_BOT = (13, 148, 136)
FLAME = (255, 255, 255)
FLAME_INNER = (254, 240, 138)


def lerp(a, b, t):
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def point_in_triangle(px, py, a, b, c):
    d1 = (px - b[0]) * (a[1] - b[1]) - (a[0] - b[0]) * (py - b[1])
    d2 = (px - c[0]) * (b[1] - c[1]) - (b[0] - c[0]) * (py - c[1])
    d3 = (px - a[0]) * (c[1] - a[1]) - (c[0] - a[0]) * (py - a[1])
    has_neg = (d1 < 0) or (d2 < 0) or (d3 < 0)
    has_pos = (d1 > 0) or (d2 > 0) or (d3 > 0)
    return not (has_neg and has_pos)


def in_flame(nx, ny, cx, cy, r, tip_y):
    if (nx - cx) ** 2 + (ny - cy) ** 2 <= r * r:
        return True
    a = (cx, tip_y)
    b = (cx - r, cy)
    c = (cx + r, cy)
    return point_in_triangle(nx, ny, a, b, c)


def sample(nx, ny, maskable):
    """Return RGB for a normalized point, or None if outside the tile."""
    # Tile background (rounded rect for normal, full square for maskable)
    if not maskable:
        radius = 0.22
        # rounded-rect coverage
        inside = True
        for (cxr, cyr) in [(radius, radius), (1 - radius, radius),
                           (radius, 1 - radius), (1 - radius, 1 - radius)]:
            if ((nx < radius and ny < radius) or
                (nx > 1 - radius and ny < radius) or
                (nx < radius and ny > 1 - radius) or
                (nx > 1 - radius and ny > 1 - radius)):
                # in a corner region: test distance to nearest corner center
                pass
        # simpler explicit corner test
        if nx < radius and ny < radius:
            inside = (nx - radius) ** 2 + (ny - radius) ** 2 <= radius ** 2
        elif nx > 1 - radius and ny < radius:
            inside = (nx - (1 - radius)) ** 2 + (ny - radius) ** 2 <= radius ** 2
        elif nx < radius and ny > 1 - radius:
            inside = (nx - radius) ** 2 + (ny - (1 - radius)) ** 2 <= radius ** 2
        elif nx > 1 - radius and ny > 1 - radius:
            inside = (nx - (1 - radius)) ** 2 + (ny - (1 - radius)) ** 2 <= radius ** 2
        if not inside:
            return None

    bg = lerp(GREEN_TOP, TEAL_BOT, ny)

    # Flame geometry — smaller & centered for maskable safe zone.
    if maskable:
        cx, cy, r, tip_y = 0.5, 0.58, 0.16, 0.30
    else:
        cx, cy, r, tip_y = 0.5, 0.60, 0.205, 0.20

    if in_flame(nx, ny, cx, cy, r, tip_y):
        # inner flame for a two-tone look
        icy = tip_y + (cy - tip_y) * 0.55
        icx, ir, itip = cx, r * 0.52, tip_y + (cy - tip_y) * 0.42
        if in_flame(nx, ny, icx, cy + (cy - icy) * 0.0 + 0.04, ir, itip):
            return FLAME_INNER
        return FLAME
    return bg


def render(size, maskable=False, ss=2):
    """Render an RGBA image with ss x ss supersampling for smooth edges."""
    px = bytearray()
    for y in range(size):
        row = bytearray()
        for x in range(size):
            r = g = b = a = 0
            for sy in range(ss):
                for sx in range(ss):
                    nx = (x + (sx + 0.5) / ss) / size
                    ny = (y + (sy + 0.5) / ss) / size
                    c = sample(nx, ny, maskable)
                    if c is None:
                        a += 0
                    else:
                        r += c[0]; g += c[1]; b += c[2]; a += 255
            n = ss * ss
            cov = a / (255 * n)
            if cov == 0:
                row += bytes((0, 0, 0, 0))
            else:
                # average color over covered subsamples
                covered = a // 255
                row += bytes((r // covered, g // covered, b // covered, round(255 * cov)))
        px += b'\x00' + row  # filter byte per scanline
    return png_bytes(size, size, px)


def png_bytes(w, h, raw_rgba_with_filter):
    def chunk(typ, data):
        c = struct.pack('>I', len(data)) + typ + data
        return c + struct.pack('>I', zlib.crc32(typ + data) & 0xffffffff)

    sig = b'\x89PNG\r\n\x1a\n'
    ihdr = struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0)  # 8-bit RGBA
    idat = zlib.compress(bytes(raw_rgba_with_filter), 9)
    return sig + chunk(b'IHDR', ihdr) + chunk(b'IDAT', idat) + chunk(b'IEND', b'')


def write(name, data):
    os.makedirs(OUT_DIR, exist_ok=True)
    path = os.path.join(OUT_DIR, name)
    with open(path, 'wb') as f:
        f.write(data)
    print('wrote', os.path.relpath(path))


if __name__ == '__main__':
    write('icon-192.png', render(192))
    write('icon-512.png', render(512))
    write('icon-512-maskable.png', render(512, maskable=True))
    write('apple-touch-icon.png', render(180))
    # favicon-sized for browser tabs
    write('favicon-32.png', render(32, ss=3))
    print('done')
