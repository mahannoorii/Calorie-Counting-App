# 🔥 CalTrack — Calorie Counter

A simple, private calorie counter you can install on your phone like a real app.
No accounts, no servers, no tracking — **everything is stored only on your device.**

It's a **Progressive Web App (PWA)**: plain HTML/CSS/JavaScript with no build step,
so it works offline and adds to your home screen with its own icon.

## Features

- **Daily calorie goal** with a live progress ring (turns red when you go over)
- **Log food** by name, calories, and meal (breakfast / lunch / dinner / snack)
- **Quick autocomplete** for ~20 common foods (auto-fills calories)
- **Day navigation** — review and edit any past day; totals per meal
- **Tap an entry to edit, trash icon to delete**
- **Works offline** and **installs to your home screen**
- **100% local** — data never leaves your phone (localStorage)

---

## 📱 How to get it on your phone

There are two ways. **Option A (hosting) is recommended** — it gives you a real
installable app icon, offline support, and updates automatically.

### Option A — Put it online for free with GitHub Pages (recommended)

1. **Merge this branch into `main`** (open a pull request, or merge it on GitHub).
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment → Source**, choose **GitHub Actions**.
   - The included workflow (`.github/workflows/deploy.yml`) then builds and
     publishes the site automatically on every push to `main`.
   - *(Alternative: choose **Deploy from a branch** → `main` / `/ (root)`.)*
4. Wait ~1 minute. Your app will be live at:

   ```
   https://mahannoorii.github.io/Calorie-Counting-App/
   ```

5. **Open that URL on your phone** and install it:

   **iPhone / iPad (Safari):**
   - Tap the **Share** button (the square with an up arrow)
   - Scroll down and tap **Add to Home Screen** → **Add**
   - CalTrack now appears as an app icon. Open it — it runs full-screen, no browser bar.

   **Android (Chrome):**
   - Tap the **⋮** menu (top right)
   - Tap **Add to Home screen** (or **Install app**) → **Install**
   - CalTrack appears in your app drawer and home screen.

   After installing, it works **offline** too.

### Option B — Try it on your computer first

```bash
# from the project folder
python3 -m http.server 8099
```

Then open <http://localhost:8099> in your browser.

> Note: a service worker (offline mode) only registers over **https** or
> **localhost**, which is exactly what GitHub Pages and the command above provide.

---

## 🗂 Project structure

```
index.html              # App markup
css/styles.css          # Styling (dark, mobile-first)
js/app.js               # All app logic (no frameworks)
manifest.webmanifest    # PWA metadata (name, icons, colors)
service-worker.js       # Offline caching
icons/                  # App icons (generated)
tools/make_icons.py     # Regenerates the icons (no dependencies)
.github/workflows/      # Auto-deploy to GitHub Pages
```

## 🔧 Notes

- **Your data:** stored in your browser's `localStorage` under the keys
  `caltrack.days.v1` and `caltrack.goal.v1`. Clearing your browser/app data
  erases it. It is per-device and never uploaded.
- **Change the icon look:** edit `tools/make_icons.py` and run
  `python3 tools/make_icons.py`.
- **After changing files**, bump `CACHE_VERSION` in `service-worker.js` so
  installed copies pick up the update.
